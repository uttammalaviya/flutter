import 'package:firebase1/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class dashboard extends StatefulWidget {
  const dashboard({Key? key}) : super(key: key);

  @override
  State<dashboard> createState() => _dashboardState();
}

class _dashboardState extends State<dashboard> {

User? user;
  @override
  initState() {
    user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      print("Not Login");
    }
    else {
      print(user!.email);
      print(user!.displayName);
      print(user!.uid);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(onPressed: () async {
            await GoogleSignIn().signOut();
            await FirebaseAuth.instance.signOut();
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return first();
            },));
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: Column(
        children: [
          Text("${user!.email}"),
          Text("${user!.displayName}"),
          Text("${user!.uid}"),
        ],
      ),
    );
  }
}
