package com.example.google_ads;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
