import 'package:flutter/material.dart';
import 'package:on_audio_query_platform_interface/details/on_audio_query_helper.dart';
import 'package:provider/provider.dart';

import 'model.dart';

class second extends StatelessWidget {
  List<SongModel> song;
  int index;
  second(this.song, this.index);

  @override
  Widget build(BuildContext context) {
    model m=Provider.of(context);
    return Scaffold(
      appBar: AppBar(title: Text("Changenotifier"),),
      body: Padding(
        padding:  EdgeInsets.only(top: 100),
        child: Center(
          child: Column(
            children: [
              Text("${song[index].title}"),
              Text("${song[index].duration}"),
              Padding(
                padding:  EdgeInsets.only(top: 400),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,children: [
                  IconButton(onPressed: () {
                      m.left(index--,song);
                  }, icon: Icon(Icons.keyboard_arrow_left,size: 50,)),
                 IconButton(onPressed: () {

                 }, icon: Icon(Icons.play_arrow,size: 50,)),
                  IconButton(onPressed: () {
                      m.right(index++,song);
                  }, icon: Icon(Icons.keyboard_arrow_right,size: 50,))
                ],),
              )
            ],
          ),
        ),
      ),
    );
  }
}
