package com.example.google_ad;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
