package com.example.payment_gateway;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
