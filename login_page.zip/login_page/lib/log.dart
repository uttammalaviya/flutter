import 'dart:io';
import 'dart:math';

import 'package:external_path/external_path.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:image_picker/image_picker.dart';
import 'package:login_page/view_data.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';

class control extends GetxController
{
  //data view
  RxList name=[].obs;
  RxList contact=[].obs;
  RxList img1=[].obs;
  RxList id=[].obs;
  RxList email=[].obs;

  RxString gender="".obs;
  RxBool img=false.obs,img3=false.obs;
  RxBool email_error=false.obs,password_error=false.obs;
  RxBool error1=false.obs,error2=false.obs,error3=false.obs,error4=false.obs;
  RxString dd="DD".obs;
  RxString mm="MM".obs;
  RxString yy="YY".obs;
  //RxList id=[].obs;

  RxList password=[].obs;
  RxBool hobby1=false.obs,hobby2=false.obs,hobby3=false.obs;
  ImagePicker _picker = ImagePicker();
  XFile? image;
TextEditingController l1=TextEditingController();
TextEditingController l2=TextEditingController();
TextEditingController t1=TextEditingController();
TextEditingController t2=TextEditingController();
TextEditingController t3=TextEditingController();
TextEditingController t4=TextEditingController();
  RxString strname="".obs,strcontact="".obs,stremail="".obs,strpassword="".obs,str_img="".obs,strhobby="".obs;
  permission1()
  async{
    var status = await Permission.storage.status;
    if(status.isDenied)
      {
        Map<Permission, PermissionStatus> statuses = await [
          Permission.storage,
        ].request();
        print(statuses[Permission.storage]);
      }
  }

 Future<void> get_image(String s)
 async {
   if(s=="camera") {
     image = await _picker.pickImage(source: ImageSource.camera);
     if( image! == null) {
     }
     img3.value=true;
     img.value=true;
   }
   else
     {
       image = await _picker.pickImage(source: ImageSource.gallery);
     }
   img.value=true;
 }

 Future<void> submit(Database database)
 async {

      strname.value=t1.text;
      strcontact.value=t2.text;
      stremail.value=t3.text;
      strpassword.value=t4.text;
      error1.value=false;
      error2.value=false;
      error3.value=false;
      error4.value=false;
     var reg_Exp=r'^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$';
     RegExp rx=RegExp(reg_Exp);
     var reg_Exp1=r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
     RegExp rx1=RegExp(reg_Exp1);
     if(strname.value.isEmpty)
        {
          error1.value=true;
        }
      else if(strcontact.value.isEmpty)
        {
          error2.value=true;
        }
      else if(!rx.hasMatch(strcontact.value))
        {
          error2.value=true;
        }
      else if(stremail.value.isEmpty)
        {
          error3.value=true;
        }
      else if(!rx1.hasMatch(stremail.value))
        {
          error3.value=true;
        }
      else if(strpassword.value.isEmpty)
        {
          error4.value=true;
        }
      else
        {

          StringBuffer br=StringBuffer();
          if(hobby1==true)
            {
              br.write("Cricket");
            }
          if(hobby2==true)
            {
              if(br.length>0)
                {
                  br.write("/");
                }
              br.write("Reading");
            }
           if(hobby3==true)
             {
               if(br.length>0)
             {
               br.write("/");
             }
               br.write("Wreting");
             }
           strhobby.value=br.toString();
           var path=await ExternalPath.getExternalStoragePublicDirectory(ExternalPath.DIRECTORY_DOWNLOADS)+"/dhruv";
           Directory dr=Directory(path);
           if(!await dr.exists())
             {
               await dr.create();
             }
           int r=Random().nextInt(99999);
           String img_name="img${r}.jpg";
           File file=File("${dr.path}/${img_name}");
           file.writeAsBytes(await image!.readAsBytes());
           str_img.value=file.path;

           print("image=${str_img.value}");
           print("hobby=${strhobby.value}");

           String insert_qur="insert into FORM values(null,'${strname.value}','${strcontact.value}','${stremail.value}','${strpassword.value}','${gender.value}','${strhobby.value}','${dd.value}','${mm.value}','${yy.value}','${str_img.value}')";
           int i=await database.rawInsert(insert_qur);
           t1.text="";
           t2.text="";
           t3.text="";
           t4.text="";

           print("hobby :-${strhobby.value}");
            print("strimg :-${str_img.value}");
           print("insert data=${i}");
          print("record is inserted");

        }
 }

 Future<void> login(Database database,context)
 async {
    String strEmail=l1.text;
    String strPassword=l2.text;
    email_error.value=false;
    password_error.value = false;
    if(strEmail.isEmpty)
    {
      email_error.value=true;
    }
    else if(strPassword.isEmpty) {
      password_error.value = true;
    }
    else
    {
      print("your data is correct");
      String cheke_qur="select * from FORM where email='$strEmail' and password='$strPassword'";
      List<Map> m=await database.rawQuery(cheke_qur);
      if(m.length==1)
        {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return view(database!);
          },));
          l1.text="";
          l2.text="";
        }
    }



 }

 Future<void> get(Database database)
  async {
    name.value.clear();
    contact.value.clear();
    img1.value.clear();
    String select_qur="select * from FORM";
    List<Map> m1=[];
    m1=await database.rawQuery(select_qur);
    m1.forEach((element) {
      name.value.add(element['name']);
      contact.value.add(element['contact']);
      email.value.add(element['email']);
      id.value.add(element['id']);
      img1.value.add(element['image']);
    });
    print("m1=${m1}");
  }

  Future<void> delete(Database database, int Index,context)
  async{
    showDialog(context: context, builder: (context) {
      return AlertDialog(title: Text("yor are syore this deta is delete"),actions: [

        TextButton(onPressed: () async {
          String delete="delete from FORM where id=${id.value[Index]}";
          int d=await database!.rawDelete(delete);
          print("delete = ${d}");
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
              return view(database);
            },));
          Navigator.pop(context);
        }, child: Text("Yes")),

        TextButton(onPressed: () {
          Navigator.pop(context);
        }, child: Text("No")),
      ],);
    },);
        }
}
