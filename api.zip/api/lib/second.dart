import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class second extends StatefulWidget {
  const second({Key? key}) : super(key: key);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  Map? m;


  get1() async {
    var url = Uri.parse('https://dummyjson.com/carts');
    var response = await http.get(url);
    print('Response status: ${response.statusCode}');
    m = jsonDecode(response.body);
    print(m);
    return m;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("second page"),
      ),
      body: FutureBuilder(future: get1(),builder: (context, snapshot) {
        if(snapshot.connectionState==ConnectionState.done){
           return ListView.builder(itemCount: 30,itemBuilder: (context, index) {
             List<dynamic> l = m!['users'] as List<dynamic>;
             print("l = ${l[index]['id']}");
             return ExpansionTile(title: Text("${l[index]['address']['coordinates']['lat']}"));
           },);
        }
        else
          {
            return Center(child: CircularProgressIndicator(),);
          }
      },),
    );
  }
}
