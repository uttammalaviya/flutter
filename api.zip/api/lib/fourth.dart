import 'dart:convert';


import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class fourth extends StatefulWidget {
  const fourth({Key? key}) : super(key: key);

  @override
  State<fourth> createState() => _fourthState();
}

class _fourthState extends State<fourth> {
  Map? m;

  get1() async {
    var url = Uri.parse('https://dummy.restapiexample.com/api/v1/employees');
    var response = await http.get(url);
    print('Response status: ${response.statusCode}');
    m = jsonDecode(response.body);
    return m;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: FutureBuilder(
        future: get1(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            print(snapshot.data);
            List<dynamic> x = m!['data'];
            print("x ${x}");
            return ListView.builder(
              itemCount: x.length,
              itemBuilder: (context, index) {
                return ExpansionTile(
                  title: Text("${x[index]['employee_name']}"),
                  children: [
                    Text("${x[index]['employee_salary']}")
                  ],
                );
              },
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
