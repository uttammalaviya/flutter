import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:phonenumber/second.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @
                    print('The provided phone number is not valid.');
                  }
                },
                codeSent: (String verificationId, int? resendToken) {
                    id=verificationId;
                },
                codeAutoRetrievalTimeout: (String verificationId) {},
              );
            }, child: Text("Send The OTP")),
            OtpTextField(
              numberOfFields: 6,
              borderColor: Color(0xFF512DA8),
              //set to true to show as box or false to show as dash
              showFieldAsBox: true,
              //runs when a code is typed in
              onCodeChanged: (String code) {
                //handle validation or checks here
              },
              //runs when every textfield is filled
              onSubmit: (String verificationCode) async {
                print(verificationCode);
                String smsCode = verificationCode;

                // Create a PhoneAuthCredential with the code
                PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: id!, smsCode: smsCode);

                // Sign the user in (or link) with the credential
                await auth.signInWithCredential(credential).then((value) {
                  if(value!=null)
                    {
                      Navigator.push(context, MaterialPageRoute(builder: (context) {
                        return second();
                      },));
                    }
                });
              }, // end onSubmit
            ),
          ],
        ),
      ),
    );
  }
}
