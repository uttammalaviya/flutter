import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:new_calculator/controlare.dart';

void main() {
  runApp(GetMaterialApp(
    home: home(),
    theme: ThemeData.dark(),
    debugShowCheckedModeBanner: false,
  ));
}

class home extends StatelessWidget {
    Controller m=Get.put(Controller());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: Colors.black,
      body:
      Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Container(alignment: Alignment.bottomRight,
          margin: EdgeInsets.all(10),child:   Obx(() => Text("${m.str.value}",style: TextStyle(fontSize: 50,fontWeight: FontWeight.bold,color: Colors.white),),),
          decoration: BoxDecoration(
              border: GradientBoxBorder(
                  width: 3,
                  gradient: LinearGradient(colors: [
                    Color(0xFFfbc7d4),
                    Color(0xFF7303c0),
                    Color(0xFFec38bc),
                    Color(0xFFfdeff9),
                  ])),
              borderRadius: BorderRadius.circular(10)),
          height: 90,
          width: double.infinity,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            InkWell(onTap: () => m.myfun("AC"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "AC",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("C"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "C",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("/"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "/",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("%"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "%",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),

          ],
        ),
        //   SizedBox(height: 35,),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            InkWell(onTap: () => m.myfun("7"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "7",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("8"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "8",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("9"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "9",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("-"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "-",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),

          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            InkWell(onTap: () => m.myfun("4"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "4",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("5"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "5",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("6"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "6",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("*"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "*",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),

          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            InkWell(onTap: () => m.myfun("1"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "1",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("2"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "2",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("3"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "3",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("+"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "+",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            InkWell(onTap: () => m.myfun("00"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "00",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("0"),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  "0",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("."),
              child: Container(
                alignment: Alignment.center,
                height: 45,
                width: 70,
                child: Text(
                  ".",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
            InkWell(onTap: () => m.myfun("="),
              child: Container(
                alignment: Alignment.center,
                height: 75,
                width: 70,
                child: Text(
                  "=",
                  style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white, blurRadius: 10, )
                    ],
                    gradient: LinearGradient(
                        colors: [Color(0xFF8E0E00), Color(0xFF1F1C18)]),
                    border: Border.all(color: Colors.white, width: 2),
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
          ],
        ),
      ]),
    );
  }
}
