import 'package:changenotifier/model.dart';
import 'package:changenotifier/second.dart';
import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:provider/provider.dart';

void main()
{
  runApp(MaterialApp(home: ChangeNotifierProvider(create: (context) => model(),child: first(),)));
}

class first extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
     model m=Provider.of(context);
    return Scaffold(
      appBar: AppBar(title: Text("Changenotifier"),),
      body:FutureBuilder(future:m.someName() ,builder: (context, snapshot) {
        if(snapshot.connectionState==ConnectionState.done)
          {
            List<SongModel> song=snapshot.data as List<SongModel>;
            return ListView.builder(itemCount:song.length ,itemBuilder: (context, index) {
              SongModel s=song[index];
              return ListTile(onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return ChangeNotifierProvider(create: (context) => model(),child: second(song,index),);
                },));
              },title: Text("${s.title}",),subtitle: Text(m.printDuration(Duration(milliseconds: s.duration!.toInt()))),);
            },);
          }
        else
          {
            return Center(child: CircularProgressIndicator(),);
          }
      },)
    );
  }
}
