import 'dart:convert';

import 'package:country_converter/user.dart';
import 'package:flutter/material.dart';
import 'package:currency_picker/currency_picker.dart';
import 'package:http/http.dart' as http;
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  String val1 = "INR";
  String val2 = "USD";
  bool b = false;



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: SafeArea(
          child: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          Center(
              child: Container(
            height: 60,
            alignment: Alignment.center,
            width: double.infinity,
            child: Center(
                child:
                    Text(style: TextStyle(fontSize: 30), "Currency Exchange")),
          )),
          SizedBox(
            height: 30,
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: t1,
                  decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "Amount",
                      hintStyle: TextStyle(color: Colors.black),
                      filled: true),
                  keyboardType: TextInputType.number,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 100,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shadowColor: Colors.grey,
                      ),
                      onPressed: () {
                        showCurrencyPicker(
                            context: context,
                            onSelect: (value) {
                              setState(() {
                                val1 = value.code;
                              });
                            },
                            showFlag: true,
                            showCurrencyName: true,
                            showCurrencyCode: true);
                      },
                      child: Text(val1)),
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                decoration: BoxDecoration(
                    color: Colors.white, borderRadius: BorderRadius.circular(100)),
                child: IconButton(
                  onPressed: () {
                    setState(() {
                      String val3 = val1;
                      val1 = val2;
                      val2 = val3;
                    });
                  },
                  icon: Icon(Icons.swap_vert),
                  color: Colors.black,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    color: Colors.white, borderRadius: BorderRadius.circular(100)),
                child: IconButton(
                  onPressed: () async {

                      var url = Uri.parse('https://jayflutter.000webhostapp.com/currency.php?to=${val1}&from=${val2}&amount=${t1.text}');
                      var response = await http.get(url);
                      print('Response status: ${response.statusCode}');
                      print('Response body: ${response.body}');
                      print("object");
                      setState(() {
                        Map m1= jsonDecode(response.body);
                        print(m1['result']);
                        t2.text="${m1['result']}";
                         print(m1);
                        // List l =[];
                        // var x = user.fromJson(m['result']);

                      });
                  },
                  icon: Icon(Icons.done),
                  color: Colors.black,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: t2,
                  decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "Amount",
                      hintStyle: TextStyle(color: Colors.black),
                      filled: true),
                  keyboardType: TextInputType.number,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 100,
                  child: ElevatedButton(
                      onPressed: () {
                        showCurrencyPicker(
                            context: context,
                            onSelect: (value) {
                              setState(() {
                                val2 = value.code;
                              });
                            },
                            showFlag: true,
                            showCurrencyName: true,
                            showCurrencyCode: true);
                      },
                      child: Text(val2)),
                ),
              )
            ],
          ),
        ],
      )),
    );
  }
}
