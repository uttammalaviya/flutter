import 'package:database_fire/user.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  DatabaseReference ref = FirebaseDatabase.instance.ref('student');
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  List<user> userlist=[];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 50,),
          TextField(controller: t1,),
          SizedBox(height: 50,),
          TextField(controller: t2,),
          ElevatedButton(onPressed: () async {
            await ref.push().set({
              "name": "${t1.text}",
              "age": "${t2.text}",
            });
          }, child: Text("submit")),
          ElevatedButton(onPressed: ()  {
            DatabaseReference starCountRef = FirebaseDatabase.instance.ref('student');
            starCountRef.onValue.listen((DatabaseEvent event) {
              Map data = event.snapshot.value as Map;
              userlist.clear();
              data.forEach((key, value) {
                print("$key=>$value");
                user u=user.fromjson(value,key);
                userlist.add(u);
              });
              setState(()  {

              });
            });
          }, child: Text("View")),
          Expanded(child: ListView.builder(shrinkWrap: true,itemCount: userlist.length,itemBuilder: (context, index) {
            return ListTile(
              title: Text("${userlist[index].name}"),
              subtitle: Text("${userlist[index].age}"),
              trailing: IconButton(onPressed: () async {
                DatabaseReference starCountRef = FirebaseDatabase.instance.ref('student/${userlist[index].key}');
                await starCountRef.ref.remove();
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return first();
                },));
              }, icon: Icon(Icons.delete)),
            );
          },)),
        ],
      ),
    );
  }
}
