package com.example.menu;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
