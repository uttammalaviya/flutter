import 'package:flutter/material.dart';

class all_shayari {
  static List<String> s_name = [
    "Bevafa Shayari",
    "Holi Shayari",
    "Life Shayari ",
    "Politics Shayari ",
    "Sad Shayari",
  ];
  static List<String> s_photo = [
    "image/bevafa.jpg",
    "image/holi-1.jpg",
    "image/life.jpg",
    "image/Politices.jpg",
    "image/sad _girls.jpg",
  ];
  static List<String> sad = [
    """Wo Tere Khat Teri Tasvir Aur Sookhe Phool,
Bahut Udaas Karti Hain Mujhko Nishaniyan Teri.""",
    """Ab Na Kholo Mere Ghar Ke Udaas Darwaze,
Hawa Ka Shor Meri Uljhanein Bada Deta Hai.""",
    """Ek Ye Khwahish Ki Koi Zakhm Na Dekhe Dil Ka,
Ek Ye Hasrat Ke Koi Dekhne Wala To Hota.""",
    """Ye Wafa Ki Sakht Raahein Ye Tumhare Paanvv Nazuk,
Na Lo Intekaam Mujhse Mere Saath-Saath Chal Ke.""",
    """Koi Aadat, Koi Baat, Ya Sirf Meri Khamoshi,
Kabhi To, Kuchh To Usey Bhi Yaad Aata Hoga.""",
    """Dilwale to hum bhi the mohabat main dil jala baithe,
takdir hi apni kuch aise thi ek bewafa se dil laga baithe.""",
    """Muzhe Maloom H K Meri Zindagi K Gam Kbhi Jane Wale Nhi,Mai 
Intezar Krunga Unka Aakhiri Sans Tak Jo Kbhi Aane Wale Nhi,""",
    """Daru aur Cigarette peenewala insaan
kabhi matlabi
nahi hota...
Jise apni khudki jaan ki chinta nahi
woh bhala
matlabi kaise.. : )""",
    """Junbaan se Naam Lete hi,
Aankhon se aansu Chalak Jaate hai...
Kabhi Hazaro baatein kiya karte the...
Aaj Ek baat ke liye taras Jaate hai...""",
    """Dard ko na dekho Dard ki nazron se,
Dard ko bhi Dard hota hai.
Dard ko bhi jaroorat hai pyar ki,
akhir pyar mein Dard hi toh humDard hota hai..""",
  ];
  static List<String> holi = [
    """Dil Ne Ek Baar Or Humara Kehna Maana Hai,
Es Holi Pe Phir Unhe Rangne Jaana Hai.""",
    """Juba Pe Tera Swad,
Badan Pe Tera Rang,
Mai To Pure Saal,
Tere Naam Ki Holi Khelta Hu.""",
    """Zamane Ke Liye To Kuchh Din Baad Holi Hai,
Magar Mujhe To Roz Rang Deti Hai Yaadein Teri.""",
    """Rang, Pichkari Hai Taiyaar,
Aao Manayein Holi Ka Pyara Tyohaar.
Happy Holi""",
    """dilo ke milne ka mausam hai,
duriyan mitane ka mausam hai,
holi ka tyauhar hi aisa hai,
rango mein dub jane ka mausam hai…
“wishing you a happy holi”""",
    """purnima ka chand, rango ki doli,
chand se uski, chandni boli,
khushiyon se bhare, apki jholi,
mubarak ho apko, rang-birangi holi…
“aap sabhi ko holi ki hardik shubhkamnaye”""",
    """hawaon mein ghula gulabi gulal,
hansi se saj gaye sabke gaal,
bura na maano holi hai kahkar,
rang biranga hua sabka haal…""",
    """dilo ko milane ka mausam hai,
duriya mitane ka mausam hai,
holi ka tyauhar hi aisa hai,
rango mein dub jane ka mausam hai…""",
    """holi ke dil ki ye mulakat yaad rahegi,
rango ki ye besumar barsat yaad rahegi,
aap ko mile rangin duniya aisi hamesha,
is tute dil ki rab se yahi fariyad rahegi…""",
    """aa jao agar aaj to milkar khele holi,
badh jaye apna pyar jo milkar khele holi,
bachpan ki dosti aur holi yaad aati hai,
kash, ek baar phir ham tum milkar khele holi…""",
  ];
  static List<String> life = [
    """The goal is not to wear brands
It is to become one""",
    """I am always hungry
For success""",
    """Make money to live
Don’t live o earn money""",
    """Pahchaanu Kaise Tujh Ko Meri Zindagi Bataa,
Gujri Hai Tu Kareeb Se Lekin Naqaab Mein.""",
    """Kash meri ZINDGI ka aanth Kuch is kadar ho
Ki meri kabr pe unka ghar ho Vo jab jab soye jameen par
Mere sine se laga unka sar ho""",
    """IshQ to humne kiya hi nahi tha
Loggo ne keh keh kar humme AshiQ bna diya""",
    """Har Waqt Milti Rahti Hain Anjani Si Saza Mujhe,
Main Kaise Poochun Taqdeer Se Mera Qasoor Kya Hai""",
    """Door rehne wale terko ek bat kehna chahta hu
agar mera khyal aaye to apna khyal rakhna""",
    """Mujhe achcha banne ka koi shaunk nahi hai
suna hai upar waala achche logon ko bahut jald apne paas bula leta hai""",
    """Mere ilawa kisi aur ko apna mehbub bnakar dekh le
tu bhi keh uthegi usme kuch aur baat thi""",
  ];
  static List<String> polit = [
    """Koi Beimaan aur rashtriy
taun ki kyon karte ko baat
loktantra ki takat hai
Janata mein dikha do Inki aukat""",
    """Duniya Karti Hai Teri Dosti
kam Kyon Hai Lekin vah Nahin
Janti ki mere dost Sare King hai""",
    """o Taur Hai Duniya ka usi Taur
se bolo baharon Ka ilaka Hai
Jahan Jara Jor se bolo""",
    """Chunav Mein Duniya Ko Dekho
muskurati aur Khushiyan
banatei Najar Aaegi""",
    """Jahan Sach Hai vahan per
Ham Khade Hain Kisi Khatir
aankhon Mein gadhe Hain""",
    """Rajniti Mein Logon Ko ab
Bada sochana chahie jaati
parti se upar uthkar Imandar
Neta Chunana chahiye""",
    """Rajniti Ka Jo Bhi Bada Ajeeb
Hota Hai vahi Roop Dushman
banta hai jo sabse khaas Hota Hai""",
    """Desh ko badalne ka jajba
sarkari Naukari Mein Aate
Hain Hain Naukari mil Jate
hi ya Damad Salon uthate Hain""",
    """Dua Karo Main Koi Rasta
nikal Sakun Tumhen bhi
dekh Sakun Khud Ko
Bhi Sambhal Sakun….""",
    """Is Nadi ki dharon mein Thandi
Hawa to Aate Hain now jarjar Si
sahi leairon se takraTi to hai""",
  ];
static List<String> be = [
    """Dil Tod Diya To Chita Bhi Jala Dena
Kafan Na Mile To Dupatta Uda Dena
Agar Koi Puche Rog Kya Tha
To Nazren Jhuka K Mohobbat Bata Dena""",
    """Itne Bure Nahi Hai Hum,Jitna Samaj Liya Hai,Yunhi Rulana Tha
Agar,Kyun Dil Hame Diya Hai,""",
    """Mehfil Na Sahi Tanhai To Milti Hai,
Milan Na Sahi Judai To Milti Hai,
Kaun Kehta Hai Ki Pyar Me Kuch Nai Milta,
Wafa Na Sahi Bawafai To""",
    """Unhe Nafrat Thi Hamse To Izhaar Kyu Kiya,
Dena Hi Tha Zeher To Phir Pyar Kyu Kiya,
De Kar Zeher Kehte Hai Peena Hoga,
Aur Jab Pee Liya .""",
    """Hum To Tere Dil Ki Mehfil Sajane Aaye The,
Teri Kasam Tujhe Apna Banane Aaye The.
Kis Baat Ki Saza Dee Tune Ham Ko,
Bewafa Hum To Tere ..""",
    """Kisi ki achhai ka Itna bhi fayda mat uthao k
wo bura banne k liye majboor ho jaye
Bura" aksar wahi banta hai
Jo Achha ban k toot Chuka hota hai""",
    """Kabhi takdeer ne sath choda kabhi zindagi ne aajmaya
Kabhi gero ne barbaad kiya toh kabhi apno ne rulaya
Koi nahi hai aaj ke waqt me kisi .""",
    """Dil me aane ka to rasta hota hai par jane ka nhi
ish liye jab bhi koi insan jata hai dil tod kar hi jata hai.""",
    """Khat likhta hu khoon se siyahi na samjhana.Marta hu teri yaad,
me bewafai na samjhana..""",
    """Sab kuch bhula diya yeh meri baffa ka kaisa sila diya
maut hume aati nahi aur zindgi hum jee pate nahi""",
  ];
 static  List<List<Color>> gradiantcolor = [
    [Color(0xff00E995),Color(0xffD080BA)],
    [Color(0xff08AEEA),Color(0xff2AF598),],
    [Color(0xfff7ff00),Color(0xffdb36a4),],
    [Color(0xffBA8B02),Color(0xf181818),],
    [Color(0xff833ab4),Color(0xffd1d1d),Color(0xfffcb045)],
    [Color(0xffFF4E50),Color(0xfF9D423),],
    [Color(0xffF9D423),Color(0xf799F0C),],
    [Color(0xff00416A),Color(0xf799F0C),Color(0xffFFE000)],
    [Color(0xffcc2b5e),Color(0xf753a88),],
    [Color(0xfffceabb),Color(0xff8b500),],
    [Color(0xff0f0c29),Color(0xf302b63),Color(0xff24243e)],
    [Color(0xff1E9600),Color(0xffFFF200),Color(0xff24243e)],
  ];

static List<String> emoji = [
  """😍😘😙😚😍""",
  """🤩😘😍☺😍""",
  """🥀🤑👌🙌🥀""",
  """🧒👦🧑👩‍""",
  """🥀🌼🌻🌞🌹""",
  """💔❣💕💞💓""",
  """💗💖💘💝💟""",
  """🧡💖💘💕🧡""",
  """😎🤩🤑🤠""",
  """❤🧡💛💚💙""",
  "",
];
static List<List<Color>> changecolor = [
    [Color(0xffff6600),Color(0xff0099ff)],
    [Color(0xff08AEEA),Color(0xff2AF598),],
    [Color(0xff009933),Color(0xff0099ff),],
    [Color(0xffFD6E6A),Color(0xffFFC600),],
    [Color(0xff6600ff),Color(0xffcc99ff),Color(0xffff6600)],
    [Color(0xffff6600),Color(0xfF6600ff),],
    [Color(0xff9900ff),Color(0xff0033cc),],
    [Color(0xffcc0099),Color(0xffff6600),],
    [Color(0xff993333),Color(0xff006699),],
    [Color(0xffccff66),Color(0xff3366ff),],
    [Color(0xff9900ff),Color(0xff006699),Color(0xffff9900)],
    [Color(0xff003399),Color(0xffcc0000)],];
}
// Expanded(
//   child: Center(
//     child: Container(
//       color: Colors.red,
//       alignment: Alignment.center,
//       child: SingleChildScrollView(
//         scrollDirection: Axis.vertical,
//         child: Container(
//           //TODO a Containar ma hight apvi ny..
//           alignment: Alignment.center,
//           padding: EdgeInsets.only(left: 10, right: 10),
//           child: Text(
//               "${emoj}\n${widget.l[widget.index]}\n${emoj}",
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                   wordSpacing: 2,
//                   color: textcolor,
//                   fontFamily: mytext1,
//                   fontSize: textsize,
//                   fontWeight: FontWeight.w400,
//                   fontStyle: FontStyle.italic)),
//           margin: EdgeInsets.all(20),
//           decoration: BoxDecoration(
//             color: bg ? backgrod : null,
//             gradient: bg ? null : LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: currentgracolor,
//                   ),
//             borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(7),
//               bottomLeft: Radius.circular(7),
//               topRight: Radius.circular(7),
//               bottomRight: Radius.circular(7),
//             ),
//           ),
//         ),
//       ),
//     ),
//   ),
// ),