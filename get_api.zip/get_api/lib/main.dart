import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: first(),));
}
class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
   dynamic ?id,email,first_name,last_name,urlo,text;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    go();
  }
  go()
  async {

    var url = Uri.http('reqres.in', 'api/users/2');
    var response = await http.get(url);

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    Map m= jsonDecode(response.body);
    print(m['data']);

    Map m2=m['data'];
    id=m2['id'];
    email=m2['email'];
    first_name=m2['first_name'];
    last_name=m2['last_name'];

    Map m3=m['support'];
    urlo=m3['url'];
    text=m3['text'];

    setState(() {

    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          children: [
            Text("$id",style: TextStyle(fontSize: 25)),
            Text("$email",style: TextStyle(fontSize: 25)),
            Text("$last_name",style: TextStyle(fontSize: 25)),
            Text("$first_name",style: TextStyle(fontSize: 25)),

            Text("$urlo",style: TextStyle(fontSize: 25)),
            Text("$text",style: TextStyle(fontSize: 25)),

          ],
        ),
      ),
    );
  }
}
