import 'package:flutter/cupertino.dart';
import 'package:on_audio_query/on_audio_query.dart';
class model extends ChangeNotifier
{
  final OnAudioQuery _audioQuery = OnAudioQuery();
  Future<List<SongModel>> someName() async {

    List<SongModel> something = await _audioQuery.querySongs();
    return something;
  }


  String printDuration(Duration duration) {
    String twoDigits(int n) {
      if (n >= 10) return "$n";
      return "0$n";
    }

    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    if (duration.inHours > 0)
      return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
    else
      return "$twoDigitMinutes:$twoDigitSeconds";
  }
  left(int i, List<SongModel> song)
  {
      notifyListeners();
  }
  right(int i, List<SongModel> song)
  {
    notifyListeners();
  }
}