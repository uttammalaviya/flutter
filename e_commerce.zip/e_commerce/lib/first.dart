import 'package:flutter/material.dart';
import 'package:getwidget/components/carousel/gf_carousel.dart';
import 'package:getwidget/components/search_bar/gf_search_bar.dart';
import 'package:getwidget/components/tabs/gf_tabbar.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> with TickerProviderStateMixin{
  late TabController tabController;

  List list = [
    "Flutter",
    "React",
    "Ionic",
    "Xamarin",
  ];

  List collist = [
  Colors.teal,
  Colors.deepPurple,
  Colors.red,
  Colors.blue,
  Colors.amber,
  ];

  final List<String> imageList = [
    "https://cdn.pixabay.com/photo/2017/12/03/18/04/christmas-balls-2995437_960_720.jpg",
    "https://cdn.pixabay.com/photo/2017/12/13/00/23/christmas-3015776_960_720.jpg",
    "https://cdn.pixabay.com/photo/2019/12/19/10/55/christmas-market-4705877_960_720.jpg",
    "https://cdn.pixabay.com/photo/2019/12/20/00/03/road-4707345_960_720.jpg",
    "https://cdn.pixabay.com/photo/2019/12/22/04/18/x-mas-4711785__340.jpg",
    "https://cdn.pixabay.com/photo/2016/11/22/07/09/spruce-1848543__340.jpg"
  ];




  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(150),
        child:Column(
          children: [
            AppBar(
              elevation: 0,
              backgroundColor: Colors.white,
              actions: [
                Column(
                  children: [
                    GFTabBar(
                      length: 2,
                      labelColor: Colors.black,
                      tabBarColor: Colors.white,
                      indicatorColor: Colors.black,
                      indicatorSize: TabBarIndicatorSize.label,
                      controller: tabController,
                      tabBarHeight: 50,
                      unselectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
                      unselectedLabelColor: Colors.black26,
                      tabs: [
                        Tab(
                          child: Text(
                            "Products",
                          ),
                        ),
                        Tab(
                          child: Text(
                            "Manufactures",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            GFSearchBar(
              searchList: list,
              searchQueryBuilder: (query, list) {
                return list
                    .where((item) =>
                    item.toLowerCase().contains(query.toLowerCase()))
                    .toList();
              },
              overlaySearchListItemBuilder: (item) {
                return Container(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    item,
                    style: const TextStyle(fontSize: 18),
                  ),
                );
              },
              onItemSelected: (item) {
                setState(() {
                  print('$item');
                });
              },
            ),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("For your business",style: TextStyle(fontWeight: FontWeight.bold),),
          GFCarousel(
            items: imageList.map(
                  (url) {
                return Container(
                  margin: EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    child: Image.network(
                        url,
                        fit: BoxFit.cover,
                        width: 1000.0
                    ),
                  ),
                );
              },
            ).toList(),
            onPageChanged: (index) {
              setState(() {
                index;
              });
            },
          ),
    ],
      ),
    );
  }

}
