
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

class Controller extends GetxController
{
  RxBool c=false.obs;
  RxString str="".obs;
  RxString str1="".obs;
  RxString str2="".obs;
  int temp=0;

  myfun(String a)
  {
    if(a=="+")
      {
        str1.value=str.value;
        str.value="";
        temp=1;
      }else if(a=="-")
        {
          str1.value=str.value;
          str.value="";
          temp=2;
        }else if(a=="*")
        {
          str1.value=str.value;
          str.value="";
          temp=3;
        }else if(a=="/")
          {
            str1.value=str.value;
            str.value="";
            temp=4;
          }
    else if(a=="C")
      {
        str.value=str.substring(0,str.value.length-1);
      }
    else if(a=="AC")
      {
        str.value="";
      }
     else if(a=="=")
      {

       int a1,a2,ans=0;
      str2.value=str.value;
       a1=int.parse(str1.value);
       a2=int.parse(str2.value);
       print("str1=${str1.value}");
       print("str2=${str2.value}");

       print("a1=${a1}");
       print("a2=${a2}");
        if(temp==1)
         {
           ans=a1+a2;
         }else if(temp==2)
           {
             ans=a1-a2;
           }else if(temp==3)
             {
               ans=a1*a2;
             }
       else if(temp==4)
         {
           ans=a1~/a2;
         }
       print("ans=${ans}");
       str.value=ans.toString();
       print("${str.value}");
      }
    else if(int.parse(a)>=0 && int.parse(a)<=9)
      {
        str.value=str.value+a;
        print("str=${str.value}");
      }

  }
}